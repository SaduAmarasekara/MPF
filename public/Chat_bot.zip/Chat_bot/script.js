async function sendMessage() {
  const input = document.getElementById('userInput').value.trim();
  const responseDiv = document.getElementById('response');
   

  if (!input) {
    responseDiv.innerHTML = 'Please enter a message.';
    return;
  }

  responseDiv.innerHTML = 'Loading...';

  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer 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', 
        'HTTP-Referer': 'http://www.webstylepress.com',
        'X-Title': 'WebStylePress',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'deepseek/deepseek-r1:free',
        messages: [{ role: 'user', content: input }],
      }),
    });

    const text = await response.text(); 
    console.log('Raw response:', text);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${text}`);
    }

    const data = JSON.parse(text);
    const markdownText = data.choices?.[0]?.message?.content || 'No response received.';
    responseDiv.innerHTML = marked.parse(markdownText);

    document.getElementById('userInput').value = '';
    responseDiv.scrollIntoView({ behavior: 'smooth' });
  } catch (error) {
    console.error('Error:', error);
    responseDiv.innerHTML = 'Error: ' + error.message;
  }
}
